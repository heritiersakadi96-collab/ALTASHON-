package com.example.musiqueplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

data class Track(val name: String, val uri: Uri)

class MainActivity : ComponentActivity() {
 private var player: ExoPlayer? = null
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  player = ExoPlayer.Builder(this).build()
  setContent {
   MaterialTheme {
    var tracks by remember { mutableStateOf(listOf<Track>()) }
    var current by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
     tracks = tracks + uris.map { uri ->
      try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
      Track(uri.lastPathSegment?.substringAfterLast('/') ?: "Chanson", uri)
     }
    }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
     Text("MUSIQUE PLAYER", style = MaterialTheme.typography.headlineMedium)
     Text("Votre bibliothèque musicale hors connexion")
     Spacer(Modifier.height(16.dp))
     Button(onClick = { picker.launch(arrayOf("audio/*")) }) { Text("Ajouter des chansons") }
     Text("Chansons : ${tracks.size}")
     LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
      itemsIndexed(tracks) { index, track ->
       TextButton(onClick = {
        current = index
        player?.setMediaItem(MediaItem.fromUri(track.uri)); player?.prepare(); player?.play(); playing = true
       }, modifier = Modifier.fillMaxWidth()) { Text("${index + 1}. ${track.name}") }
      }
     }
     Text(if (current in tracks.indices) tracks[current].name else "Aucune chanson sélectionnée")
     Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      OutlinedButton(onClick = { if (current > 0) { current--; player?.setMediaItem(MediaItem.fromUri(tracks[current].uri)); player?.prepare(); player?.play(); playing = true } }) { Text("Précédent") }
      Button(onClick = { player?.let { if (it.isPlaying) { it.pause(); playing = false } else { it.play(); playing = true } } }) { Text(if (playing) "Pause" else "Lecture") }
      OutlinedButton(onClick = { if (current < tracks.lastIndex) { current++; player?.setMediaItem(MediaItem.fromUri(tracks[current].uri)); player?.prepare(); player?.play(); playing = true } }) { Text("Suivant") }
     }
    }
   }
  }
 }
 override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
